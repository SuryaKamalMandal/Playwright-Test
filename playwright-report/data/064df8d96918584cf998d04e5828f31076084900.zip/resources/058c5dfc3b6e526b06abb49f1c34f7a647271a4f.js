(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[7177],{33394:(e,t,r)=>{Promise.resolve().then(r.bind(r,93603)),Promise.resolve().then(r.t.bind(r,78578,23)),Promise.resolve().then(r.bind(r,19870)),Promise.resolve().then(r.t.bind(r,76944,23)),Promise.resolve().then(r.bind(r,79910)),Promise.resolve().then(r.bind(r,91928)),Promise.resolve().then(r.bind(r,67263)),Promise.resolve().then(r.bind(r,54274))},54274:(e,t,r)=>{"use strict";r.d(t,{A:()=>u,AuthProvider:()=>s});var n=r(54568),o=r(7620),i=r(93514);let a=(0,o.createContext)({user:null,loading:!0});function s({children:e}){let[t,r]=(0,o.useState)(null),[s,u]=(0,o.useState)(!0);return(0,o.useEffect)(()=>{let e=(0,i.Yk)(e=>{r(e),u(!1)});return()=>e()},[]),(0,n.jsx)(a.Provider,{value:{user:t,loading:s},children:e})}function u(){let e=(0,o.useContext)(a);if(void 0===e)throw Error("useAuth must be used within an AuthProvider");return e}},67263:(e,t,r)=>{"use strict";r.d(t,{Toaster:()=>a});var n=r(54568),o=r(79227),i=r(66888);let a=({...e})=>{let{theme:t="system"}=(0,o.D)();return(0,n.jsx)(i.l$,{theme:t,className:"toaster group",toastOptions:{classNames:{toast:"group toast group-[.toaster]:bg-background group-[.toaster]:text-foreground group-[.toaster]:border-border group-[.toaster]:shadow-lg",description:"group-[.toast]:text-muted-foreground",actionButton:"group-[.toast]:bg-primary group-[.toast]:text-primary-foreground",cancelButton:"group-[.toast]:bg-muted group-[.toast]:text-muted-foreground"}},...e})}},76944:()=>{},79910:(e,t,r)=>{"use strict";r.d(t,{NextChatSDKBootstrap:()=>o});var n=r(54568);function o({baseUrl:e}){return(0,n.jsxs)(n.Fragment,{children:[(0,n.jsx)("base",{href:e}),(0,n.jsx)("script",{dangerouslySetInnerHTML:{__html:`
            window.innerBaseUrl = ${JSON.stringify(e)};
            
            (function() {
              const appOrigin = new URL(${JSON.stringify(e)}).origin;
              const isInIframe = typeof window !== "undefined" && window.self !== window.top;
              
              const htmlElement = document.documentElement;
              
              if (typeof window !== "undefined" && htmlElement) {
                const observer = new MutationObserver(function(mutations) {
                  mutations.forEach(function(mutation) {
                    if (mutation.type === "attributes" && mutation.target === htmlElement) {
                      const attrName = mutation.attributeName;
                      if (attrName && attrName.toLowerCase() !== "suppresshydrationwarning") {
                        htmlElement.removeAttribute(attrName);
                      }
                    }
                  });
                });
                
                observer.observe(htmlElement, {
                  attributes: true
                });
              }
              
              if (typeof window !== "undefined" && typeof history !== "undefined") {
                const originalReplaceState = history.replaceState;
                history.replaceState = function(state, unused, url) {
                  if (url) {
                    const u = new URL(url, window.location.href);
                    const href = u.pathname + u.search + u.hash;
                    return originalReplaceState.call(this, state, unused, href);
                  }
                  return originalReplaceState.call(this, state, unused, url);
                };
                
                const originalPushState = history.pushState;
                history.pushState = function(state, unused, url) {
                  if (url) {
                    const u = new URL(url, window.location.href);
                    const href = u.pathname + u.search + u.hash;
                    return originalPushState.call(this, state, unused, href);
                  }
                  return originalPushState.call(this, state, unused, url);
                };
              }
              
              if (typeof window !== "undefined" && typeof document !== "undefined") {
                document.addEventListener("click", function(e) {
                  let target = e.target;
                  while (target && target.nodeName !== "A") {
                    target = target.parentElement;
                  }
                  
                  if (target && target.href) {
                    try {
                      const url = new URL(target.href, window.location.href);
                      if (
                        url.origin !== appOrigin &&
                        url.origin !== window.location.origin
                      ) {
                        if (window.openai && typeof window.openai.openExternal === "function") {
                          window.openai.openExternal({ href: target.href });
                          e.preventDefault();
                        }
                      }
                    } catch (err) {
                      console.warn("openExternal failed, likely not in OpenAI client");
                    }
                  }
                }, true);
              }
              
              if (isInIframe && typeof window !== "undefined" && typeof window.fetch !== "undefined") {
                const originalFetch = window.fetch;
                window.fetch = function(input, init) {
                  try {
                    const url = typeof input === "string" 
                      ? new URL(input, window.location.href)
                      : input instanceof URL
                      ? input
                      : new URL(input.url, window.location.href);
                    
                    if (url.origin === appOrigin) {
                      const newInit = { ...init };
                      if (!newInit.mode) {
                        newInit.mode = "cors";
                      }
                      return originalFetch.call(this, url.toString(), newInit);
                    }
                    
                    if (url.origin === window.location.origin) {
                      const newUrl = new URL(${JSON.stringify(e)});
                      newUrl.pathname = url.pathname;
                      newUrl.search = url.search;
                      newUrl.hash = url.hash;
                      
                      const newInit = { ...init };
                      if (!newInit.mode) {
                        newInit.mode = "cors";
                      }
                      
                      if (input instanceof Request) {
                        return originalFetch.call(
                          this,
                          new Request(newUrl.toString(), input),
                          newInit
                        );
                      }
                      
                      return originalFetch.call(this, newUrl.toString(), newInit);
                    }
                  } catch (err) {
                    console.warn("Fetch patch error:", err);
                  }
                  
                  return originalFetch.call(this, input, init);
                };
              }
            })();
          `}})]})}},91928:(e,t,r)=>{"use strict";r.d(t,{PostHogProviderWrapper:()=>d});var n=r(54568),o=r(79748),i=r(41278),a=r(37286),s=r(7620),u=r(54274),l=r(40459);function c(){let e=(0,o.usePathname)(),t=(0,o.useSearchParams)(),{user:r}=(0,u.A)(),n=(0,s.useRef)(null),a=(0,s.useRef)(null);return(0,s.useEffect)(()=>{i.Ay.__loaded&&r?.email&&a.current!==r.email&&(a.current=r.email,i.Ay.identify(r.email,{email:r.email,email_verified:r.emailVerified}))},[r]),(0,s.useEffect)(()=>{if(!i.Ay.__loaded||!["/dashboard/organization/billing","/dashboard/support","/dashboard/onboarding"].some(t=>e?.startsWith(t)))return;let r=e+(t?.toString()?`?${t.toString()}`:"");n.current!==r&&(n.current=r,i.Ay.capture("$pageview",{$current_url:r}))},[e]),null}function d({children:e}){(0,s.useEffect)(()=>{let e="phc_NosPPa6NJO4I9Hwc26JD2PqSOwX0bda6xgJQCU0poL6",t=l.env.NEXT_PUBLIC_POSTHOG_HOST||"https://us.i.posthog.com",r="string"==typeof e&&e.startsWith("phc_XXX");!e||r||i.Ay.__loaded||i.Ay.init(e,{api_host:t,loaded:e=>{},autocapture:!1,capture_pageview:!1,capture_pageleave:!1,session_recording:{maskAllInputs:!1}})},[]);let t="phc_NosPPa6NJO4I9Hwc26JD2PqSOwX0bda6xgJQCU0poL6",r=l.env.NEXT_PUBLIC_POSTHOG_HOST||"https://us.i.posthog.com",o="string"==typeof t&&t.startsWith("phc_XXX");return!t||o?(0,n.jsx)(n.Fragment,{children:e}):(0,n.jsxs)(a.so,{apiKey:t,options:{api_host:r,autocapture:!1,session_recording:{maskAllInputs:!1}},children:[(0,n.jsx)(s.Suspense,{fallback:null,children:(0,n.jsx)(c,{})}),e]})}},93514:(e,t,r)=>{"use strict";r.d(t,{CI:()=>p,Cy:()=>c,G6:()=>h,Gg:()=>u,Yk:()=>m,p:()=>g,sn:()=>w,ti:()=>f,x9:()=>d});var n=r(71238),o=r(48054);let i={apiKey:"AIzaSyBnzh3cZR5EqWT8EWni51eeNsm4sITn89U",authDomain:"arb-admin.firebaseapp.com",projectId:"arb-admin",storageBucket:"arb-admin.appspot.com",messagingSenderId:"52654696784",appId:"1:52654696784:web:ecd0151ea4912db5212455",measurementId:"G-H5MQM4SJJM"},a=null,s=null;if(i?.apiKey)try{a=0===(0,n.Dk)().length?(0,n.Wp)(i):(0,n.Sx)(),s=(0,o.xI)(a)}catch(e){console.error("[auth] Failed to initialize Firebase client SDK.",e),a=null,s=null}let u=!!s;function l(){if(!s)throw Error("Firebase authentication is not configured. Set NEXT_PUBLIC_FIREBASE_WEB_CONFIG or legacy NEXT_PUBLIC_FIREBASE_* environment variables.");return s}function c(){return l()}async function d(e,t){let r=l();try{let n=await (0,o.x9)(r,e,t),i=await n.user.getIdToken();if(!(await fetch("/api/auth/session",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({idToken:i})})).ok)throw Error("Failed to create session");return{user:n.user,success:!0}}catch(e){throw console.error("Sign in error:",e),Error(e.message||"Failed to sign in")}}async function h(){let e=l();try{let t=new o.HF,r=await (0,o.df)(e,t),n=await r.user.getIdToken();if(!(await fetch("/api/auth/session",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({idToken:n})})).ok)throw Error("Failed to create session");return{user:r.user,success:!0}}catch(e){throw console.error("Google sign in error:",e),Error(e.message||"Failed to sign in with Google")}}async function p(){let e=l();try{await fetch("/api/auth/logout",{method:"POST"}),await (0,o.CI)(e),window.location.href="/auth/login"}catch(e){throw console.error("Sign out error:",e),Error(e.message||"Failed to sign out")}}async function f(e){let t=l();try{return await (0,o.J1)(t,e),{success:!0}}catch(e){throw console.error("Password reset error:",e),Error(e.message||"Failed to send password reset email")}}async function w(e,t){let r=l();try{return await (0,o.R4)(r,e,t),{success:!0}}catch(e){throw console.error("Password reset confirmation error:",e),Error(e.message||"Failed to reset password")}}async function g(e){let t=l();try{let r=await (0,o.p)(t,e),n=await r.user.getIdToken();if(!(await fetch("/api/auth/session",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({idToken:n})})).ok)throw Error("Failed to create session");return{user:r.user,success:!0}}catch(e){throw console.error("Custom token sign in error:",e),Error(e.message||"Failed to sign in")}}function m(e){return s?(0,o.hg)(s,e):(e(null),()=>{})}}},e=>{e.O(0,[6417,9929,803,6888,6221,6971,587,1968,7358],()=>e(e.s=33394)),_N_E=e.O()}]);
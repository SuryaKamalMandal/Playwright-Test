(function() {
  window._POSTHOG_REMOTE_CONFIG = window._POSTHOG_REMOTE_CONFIG || {};
  window._POSTHOG_REMOTE_CONFIG['phc_NosPPa6NJO4I9Hwc26JD2PqSOwX0bda6xgJQCU0poL6'] = {
    config: {"analytics": {"endpoint": "/i/v0/e/"}, "autocaptureExceptions": false, "autocapture_opt_out": false, "captureDeadClicks": false, "capturePerformance": {"network_timing": true, "web_vitals": true, "web_vitals_allowed_metrics": null}, "conversations": false, "defaultIdentifiedOnly": true, "elementsChainAsString": true, "errorTracking": {"autocaptureExceptions": false, "suppressionRules": []}, "hasFeatureFlags": false, "heatmaps": true, "logs": {"captureConsoleLogs": false}, "productTours": false, "sessionRecording": false, "supportedCompression": ["gzip", "gzip-js"], "surveys": false, "token": "phc_NosPPa6NJO4I9Hwc26JD2PqSOwX0bda6xgJQCU0poL6"},
    siteApps: [    
    {
      id: '019b3b15-004d-0000-74db-97f66848e158',
      init: function(config) { return     (function() {
        
        function buildInputs(globals, initial) {
        let inputs = {
        "domains": "",
        "selector": "",
        "useButton": "Yes",
        "buttonText": "\u2709\ufe0f",
        "buttonTitle": "",
        "buttonBackground": "",
        "buttonColor": "",
        "placeholderText": "Help us improve",
        "sendButtonText": "Send bug",
        "cancelButtonText": "Cancel",
        "thanksText": "Thank you! Closing in 3 seconds...",
        "footerHTML": "<strong class='bolded'>Have a specific issue?</strong> Contact support directly!",
        "eventName": "bug Sent",
        "bugProperty": "$bug",
        "zIndex": "999999"};
        let __getGlobal = (key) => key === 'inputs' ? inputs : globals[key];
        return inputs;}
        const source = (function () {let exports={};"use strict";
        
        Object.defineProperty(exports, "__esModule", {
          value: true
        });
        exports.onLoad = onLoad;
        function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
        function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
        function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == _typeof(i) ? i : i + ""; }
        function _toPrimitive(t, r) { if ("object" != _typeof(t) || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != _typeof(i)) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
        var style = function style(inputs) {
          return "\n    .form, .button, .thanks {\n        position: fixed;\n        bottom: 20px;\n        right: 20px;\n        color: black;\n        font-weight: normal;\n        font-family: -apple-system, BlinkMacSystemFont, \"Inter\", \"Segoe UI\", \"Roboto\", Helvetica, Arial, sans-serif, \"Apple Color Emoji\", \"Segoe UI Emoji\", \"Segoe UI Symbol\";\n        text-align: left;\n        z-index: ".concat(parseInt(inputs.zIndex) || 99999, ";\n    }\n    .button {\n        width: 64px;\n        height: 64px;\n        border-radius: 100%;\n        text-align: center;\n        line-height: 60px;\n        font-size: 32px;\n        border: none;\n        cursor: pointer;\n    }\n    .button:hover {\n        filter: brightness(1.2);\n    }\n    .form-submit[disabled] {\n        opacity: 0.6;\n        filter: grayscale(100%);\n        cursor: not-allowed;\n    }\n    .thanks {\n        background: white;\n    }\n    .form {\n        display: none;\n        flex-direction: column;\n        background: white;\n        border: 1px solid #f0f0f0;\n        border-radius: 8px;\n        padding-top: 5px;\n        max-width: 380px;\n        box-shadow: -6px 0 16px -8px rgb(0 0 0 / 8%), -9px 0 28px 0 rgb(0 0 0 / 5%), -12px 0 48px 16px rgb(0 0 0 / 3%);\n    }\n    .form textarea {\n        color: #2d2d2d;\n        font-size: 14px;\n        font-family: -apple-system, BlinkMacSystemFont, \"Inter\", \"Segoe UI\", \"Roboto\", Helvetica, Arial, sans-serif, \"Apple Color Emoji\", \"Segoe UI Emoji\", \"Segoe UI Symbol\";\n        margin-bottom: 10px;\n        background: white;\n        color: black;\n        border: none;\n        outline: none;\n        padding-left: 10px;\n        padding-right: 10px;\n        padding-top: 10px;\n    }\n    .form-submit {\n        box-sizing: border-box;\n        margin: 0;\n        font-family: inherit;\n        overflow: visible;\n        text-transform: none;\n        line-height: 1.5715;\n        position: relative;\n        display: inline-block;\n        font-weight: 400;\n        white-space: nowrap;\n        text-align: center;\n        border: 1px solid transparent;\n        cursor: pointer;\n        transition: all 0.3s cubic-bezier(0.645, 0.045, 0.355, 1);\n        user-select: none;\n        touch-action: manipulation;\n        height: 32px;\n        padding: 4px 15px;\n        font-size: 14px;\n        border-radius: 4px;\n        outline: 0;\n        color: #fff;\n        border-color: #1d4aff;\n        background: #1d4aff;\n        text-shadow: 0 -1px 0 rgba(0, 0, 0, 0.12);\n        box-shadow: 0 2px 0 rgba(0, 0, 0, 0.045);\n    }\n    .form-submit:hover {\n        filter: brightness(1.2);\n    }\n    .form-cancel {\n        box-sizing: border-box;\n        margin: 0;\n        font-family: inherit;\n        overflow: visible;\n        text-transform: none;\n        line-height: 1.5715;\n        position: relative;\n        display: inline-block;\n        font-weight: 400;\n        white-space: nowrap;\n        text-align: center;\n        border: 1px solid transparent;\n        box-shadow: 0 2px 0 rgba(0, 0, 0, 0.015);\n        cursor: pointer;\n        transition: all 0.3s cubic-bezier(0.645, 0.045, 0.355, 1);\n        user-select: none;\n        touch-action: manipulation;\n        height: 32px;\n        padding: 4px 15px;\n        font-size: 14px;\n        border-radius: 4px;\n        color: #2d2d2d;\n        border-color: rgba(0, 0, 0, 0.15);\n        background: #fff;\n        outline: 0;\n    }\n    .thanks {\n        display: none;\n        font-size: 14px;\n        padding: 20px;\n        border: 1px solid #f0f0f0;\n        border-radius: 8px;\n        box-shadow: -6px 0 16px -8px rgb(0 0 0 / 8%), -9px 0 28px 0 rgb(0 0 0 / 5%), -12px 0 48px 16px rgb(0 0 0 / 3%);\n        max-width: 340px;\n        margin-block-end: 1em;\n    }\n    .bolded { font-weight: 600; }\n    .bottom-section {\n        border-top: 1px solid #f0f0f0;\n        padding: 10px 16px;\n    }\n    .buttons {\n        display: flex;\n        justify-content: space-between;\n    }\n    .specific-issue {\n        padding-top: 10px;\n        font-size: 14px;\n        color: #747ea1;\n        font-family: -apple-system, BlinkMacSystemFont, \"Inter\", \"Segoe UI\", \"Roboto\", Helvetica, Arial, sans-serif, \"Apple Color Emoji\", \"Segoe UI Emoji\", \"Segoe UI Symbol\";\n    }\n    .specific-issue a:link {\n        color: #5879FF;\n    }\n    .specific-issue a:visited {\n        color: #5879FF;\n    }\n");
        };
        function onLoad(_ref) {
          var inputs = _ref.inputs,
            posthog = _ref.posthog;
          if (inputs.domains) {
            var domains = inputs.domains.split(',').map(function (domain) {
              return domain.trim();
            });
            if (domains.length > 0 && domains.indexOf(window.location.hostname) === -1) {
              return;
            }
          }
          var shadow = createShadow(style(inputs));
          function openbugBox() {
            Object.assign(buttonElement.style, {
              display: 'none'
            });
            Object.assign(formElement.style, {
              display: 'flex'
            });
            var closeButton = shadow.querySelector('.form-cancel');
            closeButton.addEventListener('click', function (e) {
              e.preventDefault();
              Object.assign(formElement.style, {
                display: 'none'
              });
            });
          }
          var buttonElement = Object.assign(document.createElement('button'), {
            className: 'button',
            innerText: inputs.buttonText || '?',
            onclick: openbugBox,
            title: inputs.buttonTitle || ''
          });
          Object.assign(buttonElement.style, {
            color: inputs.buttonColor || 'black',
            background: inputs.buttonBackground || '#1d8db9'
          });
          if (inputs.useButton === 'Yes') {
            shadow.appendChild(buttonElement);
          }
          var form = "\n        <textarea class='bug-textarea' name='bug' rows=6></textarea>\n        <input class='bug-textinput' name='email' placeholder=\"email\" />\n        <div class='bottom-section'>\n            <div class='buttons'>\n                <a class='form-cancel' type='button'>Close</a>\n                <button class='form-submit' type='submit' disabled>Submit</button>\n            </div>\n            <div class='specific-issue'></div>\n        </div>\n    ";
          var getSessionRecordingUrl = function getSessionRecordingUrl() {
            var _posthog$sessionRecor, _posthog$sessionManag, _posthog$config;
            var sessionId = posthog === null || posthog === void 0 || (_posthog$sessionRecor = posthog.sessionRecording) === null || _posthog$sessionRecor === void 0 ? void 0 : _posthog$sessionRecor.sessionId;
            var LOOK_BACK = 30;
            var recordingStartTime = Math.max(Math.floor((new Date().getTime() - ((posthog === null || posthog === void 0 || (_posthog$sessionManag = posthog.sessionManager) === null || _posthog$sessionManag === void 0 ? void 0 : _posthog$sessionManag._sessionStartTimestamp) || 0)) / 1000) - LOOK_BACK, 0);
            var api_host = (posthog === null || posthog === void 0 || (_posthog$config = posthog.config) === null || _posthog$config === void 0 ? void 0 : _posthog$config.api_host) || 'https://app.posthog.com';
            return sessionId ? "".concat(api_host, "/recordings/").concat(sessionId, "?t=").concat(recordingStartTime) : undefined;
          };
          var formElement = Object.assign(document.createElement('form'), {
            className: 'form',
            innerHTML: form,
            onsubmit: function onsubmit(e) {
              e.preventDefault();
              var sessionRecordingUrl = getSessionRecordingUrl();
              posthog.capture(inputs.eventName || 'bug Sent', _defineProperty(_defineProperty(_defineProperty({}, inputs.bugProperty || '$bug', this.bug.value), "sessionRecordingUrl", sessionRecordingUrl), "email", this.email.value));
              Object.assign(formElement.style, {
                display: 'none'
              });
              Object.assign(thanksElement.style, {
                display: 'flex'
              });
              window.setTimeout(function () {
                Object.assign(thanksElement.style, {
                  display: 'none'
                });
              }, 3000);
              formElement.reset();
            }
          });
          var textarea = formElement.getElementsByClassName('bug-textarea')[0];
          var emailInput = formElement.getElementsByClassName('bug-emailinput')[0];
          var cancelButton = formElement.getElementsByClassName('form-cancel')[0];
          var submitButton = formElement.getElementsByClassName('form-submit')[0];
          var footerArea = formElement.getElementsByClassName('specific-issue')[0];
          Object.assign(submitButton.style, {
            color: inputs.buttonColor || 'white',
            background: inputs.buttonBackground || '#1d8db9',
            borderColor: inputs.buttonBackground || '#1d8db9'
          });
          textarea.addEventListener('input', function (e) {
            if (textarea.value.length > 0) {
              submitButton.disabled = false;
            } else {
              submitButton.disabled = true;
            }
          });
          textarea.setAttribute('placeholder', inputs.placeholderText || 'Help us improve');
          cancelButton.innerText = inputs.cancelButtonText || 'Cancel';
          submitButton.innerText = inputs.sendButtonText || 'Send bug';
          if (inputs.footerHTML) {
            footerArea.innerHTML = inputs.footerHTML;
          } else {
            footerArea.style.display = 'none';
          }
          shadow.appendChild(formElement);
          if (inputs.selector) {
            var clickListener = function clickListener(e) {
              if (e.target.matches(inputs.selector)) {
                openbugBox();
              }
            };
            window.addEventListener('click', clickListener);
          }
          console.log('Posthog - latest bug widget');
          var thanksElement = Object.assign(document.createElement('div'), {
            className: 'thanks',
            innerHTML: '<div>' + inputs.thanksText + '</div>' || 'Thank you!'
          });
          shadow.appendChild(thanksElement);
        }
        function createShadow(styleSheet) {
          var div = document.createElement('div');
          var shadow = div.attachShadow({
            mode: 'open'
          });
          if (styleSheet) {
            var styleElement = Object.assign(document.createElement('style'), {
              innerText: styleSheet
            });
            shadow.appendChild(styleElement);
          }
          document.body.appendChild(div);
          return shadow;
        };return exports;})();
            let processEvent = undefined;
            if ('onEvent' in source) {
                processEvent = function processEvent(globals, posthog) {
                    if (!('onEvent' in source)) { return; };
                    const inputs = buildInputs(globals);
                    const filterGlobals = { ...globals.groups, ...globals.event, person: globals.person, inputs, pdi: { distinct_id: globals.event.distinct_id, person: globals.person } };
                    let __getGlobal = (key) => filterGlobals[key];
                    const filterMatches = true;
                    if (!filterMatches) { return; }
                    ;
                }
            }
        
            function init(config) {
                const posthog = config.posthog;
                const callback = config.callback;
                if ('onLoad' in source) {
                    const globals = {
                        person: {
                            properties: posthog.get_property('$stored_person_properties'),
                        }
                    }
                    const r = source.onLoad({ inputs: buildInputs(globals, true), posthog: posthog });
                    if (r && typeof r.then === 'function' && typeof r.finally === 'function') { r.catch(() => callback(false)).then(() => callback(true)) } else { callback(true) }
                } else {
                    callback(true);
                }
        
                const response = {}
        
                if (processEvent) {
                    response.processEvent = (globals) => processEvent(globals, posthog)
                }
        
                return response
            }
        
            return { init: init };
        })().init(config) } 
    }]
  }
})();